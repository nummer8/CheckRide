void FirewallCheck(HWND hwnd);
void CheckServiceState();
bool ControlSSDPService(bool start);
bool ControlUPnPPorts(bool open);
bool IsICSConnEnabled();
void checksetport(int port);